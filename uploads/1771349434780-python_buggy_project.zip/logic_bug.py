def is_even(n):
    if n % 2 == 1:
        return True
    return False
