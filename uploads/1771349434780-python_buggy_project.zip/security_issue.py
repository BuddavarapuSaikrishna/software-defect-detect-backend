import os

def run(cmd):
    os.system(cmd)  # security issue
