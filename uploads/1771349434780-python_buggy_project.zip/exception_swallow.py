def parse_int(x):
    try:
        return int(x)
    except:
        pass
