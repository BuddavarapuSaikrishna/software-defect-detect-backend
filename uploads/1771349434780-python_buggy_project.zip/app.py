def main():
    print("Hello World")
    print(undeclared_var)

if __name__ == "__main__":
    main()
