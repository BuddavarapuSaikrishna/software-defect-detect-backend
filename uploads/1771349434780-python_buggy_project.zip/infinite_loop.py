def loop():
    while True:
        pass
