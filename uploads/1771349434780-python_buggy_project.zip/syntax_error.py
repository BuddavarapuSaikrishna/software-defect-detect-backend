def broken_func()
    print("missing colon")
