def read_file(path):
    f = open(path, "r")
    data = f.read()
    # file never closed
    return data
