list = [1, 2, 3]
for list in range(5):
    print(list)
