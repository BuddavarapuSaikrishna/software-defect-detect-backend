def demo():
    x = 10
    y = 20
    return x
